void
p1_fork(int pid)
{}

void
p1_switch(int old, int new)
{}

void
p1_quit(int pid)
{}
